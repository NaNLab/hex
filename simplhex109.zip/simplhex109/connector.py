from subprocess import Popen, PIPE
from socket import socket, SOL_SOCKET, SO_REUSEADDR
from os import fork
from sys import argv

from uuid import uuid4 #pour l'extension pileouface
from hashlib import sha256 #pour l'extension pileouface
from random import randint


#-----------------------------------------------------------------------------------------
def nam(size, z):
	if len(argv)>=2 and argv[1]=="text":
		return '%c%d' % (chr(65+z[0]),z[1]+1)
	elif len(argv)>=2 and argv[1]=="graphic":
		return '%c%d' % (chr(65+z[0]),size-z[1])

def man(size, co):
	if len(argv)>=2 and argv[1]=="text":
		return (ord(co[0])-65, int(co[1:])-1)
	elif len(argv)>=2 and argv[1]=="graphic":
		return (ord(co[0])-65, size-int(co[1:]))
#-----------------------------------------------------------------------------------------




#-----------------------------------------------------------------------------------------
def recvcmd(*pot):
	s=c.recv(1024).decode('utf-8').strip()
	l=s.split(' ',1)
	if len(l)==1:
	  cmd=l[0]
	  args=''
	else:
	  (cmd,args)=l
	assert cmd in pot
	print("<<<",cmd,args)
	return (cmd,args)

def sendcmd(cmd,args):
	if args:
		 s='%s %s\n' % (cmd,args)
	else:
		 s='%s\n' % (cmd,)
	c.send(s.encode('utf-8'))
	print(">>>", cmd, args)
#-----------------------------------------------------------------------------------------



def go():
	p=Popen(['./hex109', '1000'], stdin=PIPE, stdout=PIPE)
	p.stdout.readline()
	(cmd,args) = recvcmd('bonjour')
	sendcmd('bonjour','pileouface')
	extensionsSupportees = []
	if len(args)>0 :
		extensionsSupportees = [param for param in args.split(' ')]

	recvcmd('joueur')
	sendcmd('joueur','hex109')
	(cmd,args)=recvcmd('tablier')
	sz=int(args.split(' ')[0])
	sendcmd('tablier',str(sz))
	#p.stdout.readline()
	res = p.stdout.readline().decode('utf-8').strip()
	p.stdin.write(('%d\n' % sz).encode('utf-8'))
	p.stdin.flush()
	
				
	if "pileouface" in extensionsSupportees:
		(cmd, x) = recvcmd('pileouface')

		y = str(uuid4())

		piece = ['pile','face']
		pp = randint(0,1)

		z = sha256(' '.join([x,y,piece[pp]]).encode('utf8')).hexdigest()
		sendcmd("pileouface", z)

		(cmd, t) = recvcmd('pileouface')
		sendcmd("pileouface", y)

		if piece[pp]==t:
			#print("--- L'autre joueur a gagné à pile ou face !")
			p.stdout.readline()
			p.stdin.write(('P\n').encode('utf-8'))
			p.stdin.flush()
		else:
			#print("--- J'ai gagné à pile ou face !")
			p.stdout.readline()
			p.stdin.write(('C\n').encode('utf-8'))
			p.stdin.flush()
	else:
		# on laisse le client commencer si l'extension pileouface n'est pas activée
		p.stdout.readline()
		p.stdin.write(('P\n').encode('utf-8'))
		p.stdin.flush()
	
	while True:
		s=p.stdout.readline().decode('utf-8').strip()
		if s[-5:]=='Wins!':
			recvcmd('bravo')
			sendcmd('aurevoir','')
			recvcmd('aurevoir')
			exit(1)
		elif s[:5]=='Start':
			v=s.split(' ')[-2:]
			x=int(v[0][1:-1])
			y=int(v[1][:-2])
			print("test1",v,x,y,sz)
			sendcmd('joue',nam(sz,(x,y)))
		elif s=='Play':
			(cmd,co)=recvcmd('joue','bravo','oups','aurevoir')
			if cmd=='oups':
				sendcmd('aurevoir', '')
				recvcmd('aurevoir')
				exit(1)
			elif cmd=="bravo":
				sendcmd('aurevoir', '')
				recvcmd('aurevoir')
				exit(1)
			elif cmd=='aurevoir':
				sendcmd('aurevoir', '')
				exit(1)
			else:
				(x,y)=man(sz, co)
				#print("envoie au programme", x, y)
				p.stdin.write(('%d\n' % x).encode('utf-8'))
				p.stdin.flush()
				p.stdin.write(('%d\n' % y).encode('utf-8'))
				p.stdin.flush()
				s=p.stdout.readline().decode('utf-8').strip()
				if s[-5:]=='Wins!' or s[-5:]=='wins!':
					# "CPU Player Wins!" or "CPU Resigns. Player wins!"
					sendcmd('bravo','')
					recvcmd('aurevoir')
					sendcmd('aurevoir','')
					exit(1)
				elif s[:5]=='Black':
					v=s.split(' ')[-2:]
					x=int(v[0][1:-1])
					y=int(v[1][:-2])
					sendcmd('joue',nam(sz,(x,y)))
					#print("reçoit du programme", namgraph(sz,(x,y)) ,"pour", (x,y) )
				else:
					#maybe a "segmentation fault"
					print('Oupsss!!!',s)
					sendcmd('bravo','')
					recvcmd('aurevoir')
					sendcmd('aurevoir','')
					exit(1)

if len(argv)!=2 or (argv[1] not in ["text","graphic"]):
	print("Argument must be [text|graphic]")
	exit(0)
	
s=socket()
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(('0.0.0.0',6666))
s.listen(10)
while True:
	(c,addr)=s.accept()
	cpid=fork()
	if cpid==0:
		try:
			go()
		except AssertionError:
			exit(0)
		break

