// Functions that retrieve input from the end user.

using namespace std;

namespace Player{
    int getBoardSize();
    pair<int, int> getPlayerMove();
    bool goesFirst();
}


