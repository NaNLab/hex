#include <iostream>
#include <algorithm>
#include <vector>
#include <cmath>
#include <cstdlib>
#include "game.h"
#include "hexGraph.h"
#include "hexBoard.h"

using namespace std;

void Game::gameLoop() {
    Space winner;
    bool playerWentFirst = Player::goesFirst(); // Get player input
    if (!playerWentFirst) { // Make a predetermined first move
        unsigned int rank = min(2u, board->sideLength - 1); // Account for teeny tiny boards
        board->setSpace(rank, rank, P_BLACK); // I read somewhere that 2,2 is a balanced opening move (remember pie rule).
        cout << "Start. Black just moved (2, 2)." << endl;
    }
    hexGraph gameGraph(board);
    int comMoveIndex = -1;
    while(true) {
        turn++;
	movePlayer(); // Pass whether the pi rule is in effect
	if ((winner = gameGraph.checkWinner(board))) break;
        comMoveIndex = gameGraph.getAIMove(*board, ai_monte_carlo_iterations, ai_plies, P_BLACK); // Calculate move
        board->setSpace(comMoveIndex, P_BLACK);
        if (comMoveIndex != -1) { // Remind the player of where the CPU went
            pair<int, int> comMove = board->getCoords(comMoveIndex);
            cout << "Black just moved (" << comMove.first << ", " << comMove.second << ")." << endl;
        }
	if ((winner = gameGraph.checkWinner(board))) break;
    }
    if (winner == P_WHITE) cout << "Player Wins!" << endl;
    if (winner == P_BLACK) cout << "CPU Player Wins!" << endl;
}

void Game::movePlayer(){

    pair<int, int> move;

    int badmove = false;
    do {
        if (badmove) {
            cout << "Invalid Move." << endl;
        }
        move = Player::getPlayerMove();
        badmove = true;
    } while (!board->isValidMove(move.first, move.second, false));

    // Record move in game board

    board->setSpace(move.first, move.second, P_WHITE);
}
